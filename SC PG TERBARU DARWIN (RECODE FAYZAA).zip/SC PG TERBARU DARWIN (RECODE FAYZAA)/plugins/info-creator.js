import fetch from 'node-fetch'
let handler = async (m, { conn, usedPrefix, text, args, command }) => {
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let name = await conn.getName(who)

  const sentMsg = await conn.sendContactArray(m.chat, [
    [`${nomorwa}`, `𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾𝚁𝙴`, `Developer Bot Inc`, `Ponsel`, `rajafaiz@gmail.com`, `Washington - USA`, `https://linki.ee/fayzaafx`, `Just Beginner`]
  ], m)
  }

handler.help = ['owner', 'creator']
handler.tags = ['main']
handler.command = /^(owner|creator)/i
export default handler