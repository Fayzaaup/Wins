import fs from 'fs'

let handler = async (m, { conn }) => {
	let pfft = `
👋🏻ʜᴀʟᴏ ᴄᴜʏ, ᴋᴇɴᴀʟɪɴ ɢᴡ ꜰᴀʏᴢᴀᴀ, ʙᴏᴛɴʏᴀ ꜰᴀʏᴢᴀᴀ, ʏᴀɴɢ ꜱᴏᴘᴀɴ ʏᴀ ꜱᴀᴍᴀ ᴏᴡɴᴇʀᴋᴜ.

 • sᴛᴀᴛᴜs : ᴘᴜʙʟɪᴄ
 • ʟᴀɴɢᴜᴀɢᴇ : ɴᴏᴅᴇᴊs
 • ʙᴀɪʟᴇʏ : @ᴀᴅɪᴡᴀsʜɪɴɢ
 • ʙᴀɪʟᴇʏ sᴜᴘᴘ : @ᴡʜɪsᴋᴇʏsᴏᴄᴋᴇᴛs

ᴋᴇᴛɪᴋ *.ᴀʟʟᴍᴇɴᴜ*
ᴜɴᴛᴜᴋ ᴍᴇɴᴀᴍᴘɪʟᴋᴀɴ ᴍᴇɴᴜ

_https://linki.ee/fayzaafx_
`;
 let loadd = [
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾𝚁',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾𝚁𝙴',
 '𝙻𝙾𝙰𝙳𝙸𝙽𝙶 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳...'
 ]

let { key } = await conn.sendMessage(m.chat, {text: '_Loading_'})//Pengalih isu

for (let i = 0; i < loadd.length; i++) {
await conn.sendMessage(m.chat, {text: loadd[i], edit: key })}

conn.sendMessage(m.chat, {
    video: fs.readFileSync('./media/thumb2.mp4'),
    mimetype: 'video/mp4',
    fileLength: 100000000000,
    caption: pfft,
    gifPlayback: true,
    gifAttribution: 5,
    contextInfo: {
      forwardingScore: 2023, 
      isForwarded: false,
      mentionedJid: [m.sender]
    }
  },
  )
  conn.sendMessage(m.chat, { audio: fs.readFileSync('./media/menu.mp3'), quoted: m });
/*
conn.sendMessage(m.chat, {
      text: pfft,
      contextInfo: {
      externalAdReply: {
      title: `𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾𝚁𝙴`,
      body: global.author,
      thumbnailUrl: `https://telegra.ph/file/465928728c79193acd47f.jpg`,
      sourceUrl: sgc,
      mediaType: 1,
      renderLargerThumbnail: true
      }}})*/
}
handler.command = /^(menu|help)$/i;

export default handler;