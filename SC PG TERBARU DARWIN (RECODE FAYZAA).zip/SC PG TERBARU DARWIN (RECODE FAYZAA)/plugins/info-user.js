import fs from 'fs'
import moment from 'moment-timezone'

let handler = async (m, { usedPrefix, command, conn, text }) => {
  let mentionedJid = [m.sender]
let name = conn.getName(m.sender)
    let totalreg = Object.keys(global.db.data.users).length
    let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length
    let kon = `*Database Saat Ini ${totalreg} User*\n*Terdaftar Saat Ini ${rtotalreg} User*`
let loadd = [
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾𝚁',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾𝚁𝙴',
 '𝙻𝙾𝙰𝙳𝙸𝙽𝙶 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳...'
 ]

let { key } = await conn.sendMessage(m.chat, {text: '_Loading_'})//Pengalih isu

for (let i = 0; i < loadd.length; i++) {
await conn.sendMessage(m.chat, {text: loadd[i], edit: key })}
}
handler.help = ['user']
handler.tags = ['info']
handler.command = /^(pengguna|(jumlah)?database|user)$/i

export default handler
