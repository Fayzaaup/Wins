let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender]
  let loadd = [
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾𝚁',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾𝚁𝙴',
 '𝙻𝙾𝙰𝙳𝙸𝙽𝙶 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳...'
 ]

let { key } = await conn.sendMessage(m.chat, {text: '_Loading_'})//Pengalih isu

for (let i = 0; i < loadd.length; i++) {
await conn.sendMessage(m.chat, {text: loadd[i], edit: key })}
  const caption = `
▧「 *PEMBAYARAN* 」

🎗️E-Walet
• Dana = PM OWNER
• Gopay = PM OWNER
• Qris = https://bit.ly/3PFNdBT

⚠️ 𝗦𝗲𝗿𝘁𝗮𝗸𝗮𝗻 𝗦𝗰𝗿𝗲𝗲𝗻𝘀𝗵𝗼𝘁 [!]
𝗧𝗿𝗮𝗻𝘀𝗮𝗸𝘀𝗶 𝗱𝗶 𝗖𝗵𝗮𝘁 𝗣𝗿𝗶𝗯𝗮𝗱𝗶 [!] 
`.trim()
  conn.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/c3cc0afda69284d54a8d5.jpg' }, caption: caption }, {quoted: m })
}
handler.command = /^(topup|ball)$/i

handler.register = false
export default handler