import fs from 'fs'

let handler = async (m, { conn }) => {
let loadd = [
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾𝚁𝙴',
 'https://linki.ee/fayzaafx',
 'https://linki.ee/fayzaafx2',
 'Sewa Bot?',
 'Pm 081295169487',
 '𝙻𝙾𝙰𝙳𝙸𝙽𝙶 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳...'
 ]

let { key } = await conn.sendMessage(m.chat, {text: '_Loading_'})//Pengalih isu

for (let i = 0; i < loadd.length; i++) {
await conn.sendMessage(m.chat, {text: loadd[i], edit: key })}
	let pfft = `*Sc By Bang Winn - MD V.1.0*
	
*Source Code Type:*
 • Base : Plugins
 • Language : NodeJs
 • Bailey : @adiwashing/baileys
 • Bailey Supp : @whiskeysockets/baileys

Jika anda menginginkan Script ini silahkan hubungi nomor dibawah ini:

Owner Contact:
wa.me/6281295169487
`;
conn.sendMessage(m.chat, {
      text: pfft,
      contextInfo: {
      externalAdReply: {
      title: `𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾𝚁𝙴`,
      body: global.author,
      thumbnailUrl: `https://telegra.ph/file/465928728c79193acd47f.jpg`,
      sourceUrl: sgc,
      mediaType: 1,
      renderLargerThumbnail: true
      }}})
}
handler.command = /^(sc|script)$/i;

export default handler;