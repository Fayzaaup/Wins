let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender]
  let loadd = [
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾𝚁',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾𝚁𝙴',
 '𝙻𝙾𝙰𝙳𝙸𝙽𝙶 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳...'
 ]

let { key } = await conn.sendMessage(m.chat, {text: '_Loading_'})//Pengalih isu

for (let i = 0; i < loadd.length; i++) {
await conn.sendMessage(m.chat, {text: loadd[i], edit: key })}
  const caption = `
*JOKI TURNAMEN BY FAYZAA STORE*

Pricelist :

JASA JOKI RANK THE SPIKE
NEWBIE - AMATIR › Rp 5.000
NEWBIE - PRO        › Rp 10.000
NEWBIE - WORLD  › Rp 15.000

LIST JASA SPIN PLAYER
NISHIKAWA › Rp 8.000
YAMADE ㅤ  › Rp 5.000
SOHEE          › Rp 5.000
SIWOO          › Rp 8.000
`.trim()
  conn.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/465928728c79193acd47f.jpg' }, caption: caption }, {quoted: m })
}
handler.command = /^(joki)$/i

handler.register = false
export default handler