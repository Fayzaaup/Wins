let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender]
  let loadd = [
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾𝚁',
 '𝙵𝙰𝚈𝚉𝙰𝙰𝙵𝚇 𝚂𝚃𝙾𝚁𝙴',
 '𝙻𝙾𝙰𝙳𝙸𝙽𝙶 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳...'
 ]

let { key } = await conn.sendMessage(m.chat, {text: '_Loading_'})//Pengalih isu

for (let i = 0; i < loadd.length; i++) {
await conn.sendMessage(m.chat, {text: loadd[i], edit: key })}
  const caption = `
*MC BY FAYZAA*
List Fee mc :

› 0 - 40K = 3K
› 41 - 100K = 5K
› 101 - 500K = 10K
*_TRX BATAL FEE TETEP KEPOTONG_*
`.trim()
  conn.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/465928728c79193acd47f.jpg' }, caption: caption }, {quoted: m })
}
handler.command = /^(mc)$/i

handler.register = false
export default handler